import React, { useState } from 'react';
import { InferenceEngine } from './utils/inferenceEngine';
import { carDatabase } from './data/carDatabase';
import { Header } from './components/Header';
import { BudgetInput } from './components/BudgetInput';
import { ResultsSection } from './components/ResultsSection';
import { Background } from './components/Background';

const inferenceEngine = new InferenceEngine(carDatabase);

function App() {
  const [budget, setBudget] = useState('');
  const [recommendations, setRecommendations] = useState([]);

  const handleBudgetSubmit = () => {
    if (budget) {
      const results = inferenceEngine.getRecommendations(Number(budget));
      setRecommendations(results);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 py-12 px-4 sm:px-6 lg:px-8 relative">
      <Background />
      <div className="max-w-7xl mx-auto relative">
        <Header />
        
        <div className="max-w-xl mx-auto">
          <BudgetInput 
            budget={budget} 
            setBudget={setBudget}
            onSubmit={handleBudgetSubmit}
          />
        </div>

        <ResultsSection recommendations={recommendations} />
      </div>
    </div>
  );
}

export default App;