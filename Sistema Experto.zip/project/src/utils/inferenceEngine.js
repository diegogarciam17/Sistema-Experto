export class InferenceEngine {
  constructor(database) {
    this.database = database;
  }

  // Forward chaining inference based on budget
  inferCarsByBudget(budget) {
    return this.database.filter(car => 
      budget >= car.minBudget && budget <= car.maxBudget
    );
  }

  // Get recommendations based on multiple criteria
  getRecommendations(budget, preferences = []) {
    let recommendations = this.inferCarsByBudget(budget);
    
    if (preferences.length > 0) {
      recommendations = recommendations.filter(car => 
        preferences.some(pref => 
          car.features.includes(pref) || 
          car.recommendedFor.includes(pref)
        )
      );
    }

    return recommendations.sort((a, b) => {
      // Sort by how well the car matches the budget (closer to budget = better)
      const aBudgetDiff = Math.abs(budget - a.price);
      const bBudgetDiff = Math.abs(budget - b.price);
      return aBudgetDiff - bBudgetDiff;
    });
  }

  // Get unique categories from the database
  getCategories() {
    return [...new Set(this.database.map(car => car.category))];
  }

  // Get unique features from the database
  getFeatures() {
    const features = new Set();
    this.database.forEach(car => {
      car.features.forEach(feature => features.add(feature));
    });
    return [...features];
  }
}