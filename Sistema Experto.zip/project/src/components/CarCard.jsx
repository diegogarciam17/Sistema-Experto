import React from 'react';
import { motion } from 'framer-motion';
import { TagIcon, UserGroupIcon } from '@heroicons/react/24/outline';

export function CarCard({ car, index }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow duration-300"
    >
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="text-xl font-bold text-gray-900">
              {car.brand} {car.model}
            </h3>
            <p className="text-gray-600">{car.year}</p>
          </div>
          <span className="px-4 py-2 bg-green-100 text-green-800 rounded-full font-semibold">
            ${car.price.toLocaleString()}
          </span>
        </div>

        <div className="space-y-4">
          <div>
            <div className="flex items-center mb-2">
              <TagIcon className="h-5 w-5 text-blue-500 mr-2" />
              <span className="font-semibold text-gray-700">Características</span>
            </div>
            <ul className="ml-7 space-y-1">
              {car.features.map((feature, idx) => (
                <li key={idx} className="text-gray-600">• {feature}</li>
              ))}
            </ul>
          </div>

          <div>
            <div className="flex items-center mb-2">
              <UserGroupIcon className="h-5 w-5 text-blue-500 mr-2" />
              <span className="font-semibold text-gray-700">Recomendado para</span>
            </div>
            <ul className="ml-7 space-y-1">
              {car.recommendedFor.map((rec, idx) => (
                <li key={idx} className="text-gray-600">• {rec}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </motion.div>
  );
}