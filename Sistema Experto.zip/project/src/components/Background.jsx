import React from 'react';
import { motion } from 'framer-motion';

export function Background() {
  return (
    <div className="fixed inset-0 -z-10 overflow-hidden">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.04 }}
        transition={{ duration: 1 }}
        className="absolute inset-0 flex items-center justify-center"
      >
        <svg
          width="800"
          height="800"
          viewBox="0 0 192 192"
          className="w-[800px] h-[800px] text-blue-900 rotate-12 transform"
        >
          <path
            fill="currentColor"
            d="M96 0L27.17 23.96v55.24c0 51.38 29.14 99.05 68.83 111.76 39.69-12.71 68.83-60.38 68.83-111.76V23.96L96 0zm57.57 79.2c0 45.89-25.86 88.28-57.57 99.08-31.71-10.8-57.57-53.19-57.57-99.08V30.35L96 9.89l57.57 20.46v48.85z"
          />
          <path
            fill="currentColor"
            d="M96 40.23L48.43 56.91v22.29c0 34.4 21.4 66.2 47.57 74.57 26.17-8.37 47.57-40.17 47.57-74.57V56.91L96 40.23zm36.31 38.97c0 28.91-16.3 55.65-36.31 62.45-20.01-6.8-36.31-33.54-36.31-62.45v-13.9L96 53.12l36.31 12.18v13.9z"
          />
        </svg>
      </motion.div>
    </div>
  );
}