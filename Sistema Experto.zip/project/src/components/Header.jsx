import React from 'react';
import { motion } from 'framer-motion';

export function Header() {
  return (
    <motion.div 
      className="text-center mb-12"
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-4xl font-bold text-gray-900 mb-4">
        Bienvenido a Dynasty Expert
      </h1>
      <p className="text-xl text-gray-600 max-w-2xl mx-auto">
        Encuentra el vehículo perfecto que se ajuste a tu presupuesto y necesidades
      </p>
    </motion.div>
  );
}