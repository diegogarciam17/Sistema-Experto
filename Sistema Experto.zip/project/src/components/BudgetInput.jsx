import React from 'react';
import { motion } from 'framer-motion';
import { CurrencyDollarIcon } from '@heroicons/react/24/outline';

export function BudgetInput({ budget, setBudget, onSubmit }) {
  return (
    <motion.div 
      className="bg-white rounded-xl shadow-lg p-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <div className="mb-6">
        <label 
          htmlFor="budget" 
          className="block text-lg font-semibold text-gray-700 mb-3"
        >
          ¿Cuál es tu presupuesto?
        </label>
        <div className="relative rounded-md shadow-sm">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <CurrencyDollarIcon className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="number"
            id="budget"
            value={budget}
            onChange={(e) => setBudget(e.target.value)}
            className="block w-full pl-10 pr-12 py-3 text-lg rounded-lg border-gray-300 
                     focus:ring-blue-500 focus:border-blue-500 border-2
                     transition-colors duration-200"
            placeholder="Ingresa tu presupuesto"
            min="0"
          />
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
            <span className="text-gray-500 sm:text-lg">MXN</span>
          </div>
        </div>
      </div>
      
      <motion.button
        onClick={onSubmit}
        className="w-full bg-blue-600 text-white text-lg font-semibold rounded-lg 
                 py-3 px-4 hover:bg-blue-700 focus:outline-none focus:ring-2 
                 focus:ring-blue-500 focus:ring-offset-2 transition-colors duration-200"
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
      >
        Buscar Recomendaciones
      </motion.button>
    </motion.div>
  );
}