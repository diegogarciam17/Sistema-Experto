import React from 'react';
import { motion } from 'framer-motion';
import { CarCard } from './CarCard';
import { ExclamationTriangleIcon } from '@heroicons/react/24/outline';

export function CarList({ recommendations }) {
  if (recommendations.length === 0) {
    return (
      <motion.div 
        className="text-center py-8"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <ExclamationTriangleIcon className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
        <p className="text-lg text-gray-600">
          No se encontraron vehículos que coincidan con tus criterios.
        </p>
      </motion.div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {recommendations.map((car, index) => (
        <CarCard key={car.id} car={car} index={index} />
      ))}
    </div>
  );
}