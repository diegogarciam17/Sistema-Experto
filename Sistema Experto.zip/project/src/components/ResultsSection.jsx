import React from 'react';
import { motion } from 'framer-motion';
import { CarList } from './CarList';

export function ResultsSection({ recommendations }) {
  if (!recommendations.length) return null;

  return (
    <motion.div 
      className="bg-white rounded-xl shadow-lg p-8 mt-8"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h2 className="text-2xl font-bold text-gray-900 mb-6">
        Vehículos Recomendados
      </h2>
      <CarList recommendations={recommendations} />
    </motion.div>
  );
}