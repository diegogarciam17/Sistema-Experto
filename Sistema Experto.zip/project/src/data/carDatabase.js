export const carDatabase = [
  {
    id: 1,
    brand: "Toyota",
    model: "Corolla",
    year: 2023,
    price: 403960,
    category: "Sedan",
    features: [
      "Consumo eficiente de combustible",
      "Sistema de seguridad Toyota Safety Sense",
      "Pantalla táctil de 8 pulgadas",
      "Apple CarPlay y Android Auto"
    ],
    recommendedFor: ["Uso diario", "Familia", "Primer auto"],
    minBudget: 350000,
    maxBudget: 450000
  },
  {
    id: 2,
    brand: "Honda",
    model: "Civic",
    year: 2023,
    price: 440000,
    category: "Sedan",
    features: [
      "Diseño deportivo",
      "Honda Sensing Suite",
      "Economía de combustible superior",
      "Sistema de audio premium"
    ],
    recommendedFor: ["Jóvenes profesionales", "Entusiastas de la conducción"],
    minBudget: 400000,
    maxBudget: 450000
  },
  {
    id: 3,
    brand: "Ford",
    model: "Mustang",
    year: 2023,
    price: 706930,
    category: "Deportivo",
    features: [
      "Motor V8 de alto rendimiento",
      "Diseño icónico",
      "Modos de conducción seleccionables",
      "Sistema SYNC 4"
    ],
    recommendedFor: ["Entusiastas de autos deportivos", "Coleccionistas"],
    minBudget: 650000,
    maxBudget: 750000
  },
  {
    id: 4,
    brand: "Chevrolet",
    model: "Spark",
    year: 2023,
    price: 302907,
    category: "Compacto",
    features: [
      "Excelente economía de combustible",
      "Fácil de estacionar",
      "Bajo costo de mantenimiento",
      "Ideal para ciudad"
    ],
    recommendedFor: ["Estudiantes", "Uso urbano", "Primer auto"],
    minBudget: 250000,
    maxBudget: 350000
  },
  {
    id: 5,
    brand: "Volkswagen",
    model: "Golf GTI",
    year: 2023,
    price: 605940,
    category: "Hot Hatch",
    features: [
      "Motor turbo de alto rendimiento",
      "Suspensión deportiva adaptativa",
      "Interior premium",
      "Tecnología de punta"
    ],
    recommendedFor: ["Entusiastas del performance", "Uso diario deportivo"],
    minBudget: 550000,
    maxBudget: 650000
  },
  {
    id: 6,
    brand: "Tesla",
    model: "Model 3",
    year: 2024,
    price: 749000,
    category: "Eléctrico",
    features: [
      "Totalmente eléctrico",
      "Autopilot",
      "Pantalla táctil de 15 pulgadas",
      "Actualizaciones over-the-air"
    ],
    recommendedFor: ["Tecnófilos", "Ecologistas", "Innovadores"],
    minBudget: 700000,
    maxBudget: 800000
  },
  {
    id: 7,
    brand: "Hyundai",
    model: "Tucson",
    year: 2023,
    price: 525148,
    category: "SUV",
    features: [
      "Diseño moderno",
      "Amplio espacio interior",
      "Sistema de asistencia al conductor",
      "Garantía extendida"
    ],
    recommendedFor: ["Familias", "Aventureros", "Uso versátil"],
    minBudget: 500000,
    maxBudget: 600000
  },
  {
    id: 8,
    brand: "Mazda",
    model: "CX-5",
    year: 2023,
    price: 565544,
    category: "SUV",
    features: [
      "Diseño premium",
      "Interior lujoso",
      "i-Activ AWD",
      "Sistema de sonido Bose"
    ],
    recommendedFor: ["Profesionales", "Familias", "Amantes del lujo"],
    minBudget: 500000,
    maxBudget: 600000
  },
  {
    id: 9,
    brand: "Kia",
    model: "Rio",
    year: 2023,
    price: 343366,
    category: "Compacto",
    features: [
      "Excelente valor por dinero",
      "Bajo consumo de combustible",
      "Garantía líder en la industria",
      "Apple CarPlay/Android Auto"
    ],
    recommendedFor: ["Compradores prácticos", "Primer auto", "Uso urbano"],
    minBudget: 300000,
    maxBudget: 400000
  },
  {
    id: 10,
    brand: "BMW",
    model: "Serie 3",
    year: 2023,
    price: 848316,
    category: "Sedan de lujo",
    features: [
      "Motor TwinPower Turbo",
      "Interior premium",
      "Sistema iDrive",
      "Asistentes de conducción avanzados"
    ],
    recommendedFor: ["Ejecutivos", "Entusiastas del lujo", "Profesionales exitosos"],
    minBudget: 800000,
    maxBudget: 900000
  },
    {
    id: 11,
    brand: "BYD",
    model: "Dolphin Mini",
    year: 2024,
    price: 398000,
    category: "Compacto",
    features: [
      "Diseño moderno",
      "Interior lujoso",
      "AWD",
      "Sistema de sonido Bose"
    ],
    recommendedFor: ["Estudiantes", "Flotillas", "Amantes de la tecnologia"],
    minBudget: 300000,
    maxBudget: 400000
  },
  {
    id: 12,
    brand: "Mercedes Benz",
    model: "C200 Sport",
    year: 2024,
    price: 1099000,
    category: "Lujoso",
    features: [
      "Diseño deportivo",
      "Interior lujoso",
      "RWD",
      "Sistema de sonido Burmister"
    ],
    recommendedFor: ["Viajeros", "Ejecutivos", "Amantes de la tecnologia"],
    minBudget: 1000000,
    maxBudget: 1200000
  },
   {
    id: 13,
    brand: "Mercedes AMG",
    model: "C43 AMG",
    year: 2024,
    price: 1610000,
    category: "Deportivo",
    features: [
      "Diseño deportivo",
      "Interior lujoso",
      "4MATIC",
      "Sistema de sonido Burmister"
    ],
    recommendedFor: ["Jovenes", "Amantes de la Velosidad", "Puristas"],
    minBudget: 1000000,
    maxBudget: 2000000
  },
   {
   id: 14,
    brand: "Mercedes AMG",
    model: "C63S E PERFORMANCE",
    year: 2024,
    price: 2399000,
    category: "Deportivo",
    features: [
      "Diseño deportivo",
      "Interior lujoso",
      "4MATIC",
      "Sistema de sonido Burmister"
    ],
    recommendedFor: ["Jovenes", "Amantes de la Velosidad", "Puristas"],
    minBudget: 2000000,
    maxBudget: 3000000
  },
];